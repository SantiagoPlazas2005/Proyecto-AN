package com.Corhuila.ReservaCancha;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ReservaCanchaApplication {

	public static void main(String[] args) {
		SpringApplication.run(ReservaCanchaApplication.class, args);
	}

}
